﻿using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Serialization;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UWPDemoNameGenerator
{
    //Create the student object
    [XmlRoot("ArrayOfStudents")]
    public class Students
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int StudentID { get; set; }
        public int TrackStudents { get; set; }
        public Students() { }
        //load the xml file directly to the object list in the form of the students class
        public List<Students> LoadFileDB()
        {
            string filePath = ".\\NamesDB.xml";
            XDocument doc = XDocument.Load(filePath);
            List<Students> theseParts = new List<Students>();
            theseParts = doc.Element("ArrayOfStudents")
                .Elements("Student")
                .Select(s => new Students()
                {
                    FirstName = (string)s.Element("FirstName"),
                    LastName = (string)s.Element("LastName"),
                    StudentID = (int)s.Element("StudentID"),
                    TrackStudents = (int)s.Element("TrackStudents")
                }).ToList();
            return theseParts;
        }
        //not implemented but creates a way to write back to the xml for later
        public void SaveToFile(string filePath)
        {
            List<Students> theseStudents = new List<Students>();
            TextWriter writer = new StreamWriter(File.OpenWrite(filePath));
            XmlSerializer serializer = new XmlSerializer(typeof(List<Students>));
            serializer.Serialize(writer, theseStudents);
        }
    }
}

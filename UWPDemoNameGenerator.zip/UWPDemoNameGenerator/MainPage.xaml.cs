﻿using System;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Popups;
using System.Collections.Generic;
using System.Collections.ObjectModel;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace UWPDemoNameGenerator
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            //create a new instance of Students so we can access the methods
            Students students = new Students();
            //create a new list instance of Students so that we can dump the database into it
            List<Students> theseStudents = students.LoadFileDB();
            // effectively cast the list to an observable collection for the itemslist
            ObservableCollection<Students> dataList = new ObservableCollection<Students>(theseStudents);
            //use linq to return the list students object by first name and populate the .ItemSource for the ListView created in MainPage.xaml
            StudentListing.ItemsSource = (from i in dataList
                                        orderby i.FirstName ascending
                                        select i);
        }

        private async void btnGenName_Click(object sender, RoutedEventArgs e)
        {
            //This method returns a random student name in a popup window
            Students students = new Students();
            List<Students> theseStudents = students.LoadFileDB();
            Random rand = new Random();
            Students thisStudent = theseStudents[rand.Next(theseStudents.Count)];
            thisStudent.TrackStudents = thisStudent.TrackStudents + 1;
            string msg = "Student Name: " + thisStudent.FirstName + " " + thisStudent.LastName;
            var msgDialog = new MessageDialog(msg);
            msgDialog.Commands.Add(new UICommand("OK"));
            await msgDialog.ShowAsync();
            pgClose(null, e);
        }
        private async void StudentList_Click(object sender, ItemClickEventArgs e)
        {
            //Retrieves the student click and displays how many times that student has been called
            Students thisStudent = (Students)e.ClickedItem;
            string msg = thisStudent.FirstName + " has been called " + thisStudent.TrackStudents + " times.";
            var msgDialog = new MessageDialog(msg);
            msgDialog.Commands.Add(new UICommand("OK"));
            await msgDialog.ShowAsync();
        }

        private void pgClose(object sender, RoutedEventArgs e)
        {
            string filePath = "./NamesDBTest.xml";
            Students mainPage = new Students();
            mainPage.SaveToFile(filePath);
        }
    }
}
